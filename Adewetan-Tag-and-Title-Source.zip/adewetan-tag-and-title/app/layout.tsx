import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Adewetan Tag & Title | Maryland Vehicle Services",
  description:
    "Maryland title transfers, registration, tags, duplicate titles, salvage vehicle support, appointments, and online payments.",
  keywords: [
    "Maryland tag and title",
    "Maryland title transfer",
    "Maryland vehicle registration",
    "Maryland license plates",
    "duplicate vehicle title",
    "salvage rebuilt vehicle Maryland",
  ],
  openGraph: {
    title: "Adewetan Tag & Title | Maryland Vehicle Services",
    description: "Clear, appointment-based help with Maryland titles, registration, tags, duplicate titles, and complex vehicle paperwork.",
    type: "website",
  },
  other: {
    "codex-preview": "development",
  },
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased`}
      >
        {children}
      </body>
    </html>
  );
}
