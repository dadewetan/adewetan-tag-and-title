"use client";

import { useEffect, useMemo, useRef, useState } from "react";

type Service = {
  number: string;
  slug: string;
  title: string;
  description: string;
  includes: string[];
  accent: "yellow" | "red" | "green";
};

type Guide = {
  title: string;
  category: string;
  status: "checked" | "verify";
  summary: string;
  keywords: string[];
  source: string;
};

const services: Service[] = [
  {
    number: "01",
    slug: "title-transfers",
    title: "Title transfers",
    description: "A guided path for private purchases, gifts, inherited vehicles, and ownership changes.",
    includes: ["Document review", "Ownership checklist", "Submission guidance"],
    accent: "yellow",
  },
  {
    number: "02",
    slug: "registration-renewals",
    title: "Registration & renewals",
    description: "Get Maryland registration paperwork organized and resolve common renewal blockers.",
    includes: ["Renewal preparation", "Vehicle flag review", "Registration questions"],
    accent: "green",
  },
  {
    number: "03",
    slug: "tags-license-plates",
    title: "Tags & license plates",
    description: "Support for standard plates, transfers, replacements, and transaction-specific tag needs.",
    includes: ["Plate options", "Transfer preparation", "Replacement guidance"],
    accent: "red",
  },
  {
    number: "04",
    slug: "duplicate-titles",
    title: "Duplicate titles",
    description: "Replace a lost, damaged, or destroyed Maryland vehicle title with fewer surprises.",
    includes: ["VR-018 checklist", "Lien-status review", "Application preparation"],
    accent: "yellow",
  },
  {
    number: "05",
    slug: "salvage-rebuilt-vehicles",
    title: "Salvage & rebuilt vehicles",
    description: "Navigate branded-title paperwork, inspection questions, and the rebuild-to-road process.",
    includes: ["Title-brand review", "Inspection roadmap", "Document checklist"],
    accent: "red",
  },
  {
    number: "06",
    slug: "mobile-remote-service",
    title: "Mobile or remote service",
    description: "Start from home with a document review before an in-person transaction is needed.",
    includes: ["Remote intake", "Document pre-check", "Appointment planning"],
    accent: "green",
  },
];

const guides: Guide[] = [
  {
    title: "New Maryland resident",
    category: "Registration",
    status: "checked",
    summary: "Maryland title and registration starting points for an out-of-state vehicle.",
    keywords: ["moving", "out of state", "60 days", "new resident"],
    source: "https://mva.maryland.gov/your-mva-guide/new-maryland-residents",
  },
  {
    title: "Duplicate vehicle title",
    category: "Title",
    status: "checked",
    summary: "Core documents, lien questions, and the official replacement-title path.",
    keywords: ["lost title", "duplicate", "vr-018", "lien"],
    source: "https://mva.maryland.gov/title-registration/request-duplicate-title",
  },
  {
    title: "Registration renewal",
    category: "Registration",
    status: "checked",
    summary: "Insurance, vehicle flags, payment, and renewal eligibility checkpoints.",
    keywords: ["renewal", "registration", "flags", "insurance"],
    source: "https://mva.maryland.gov/title-registration/renew-registration",
  },
  {
    title: "Salvage or rebuilt vehicle",
    category: "Special case",
    status: "checked",
    summary: "A starting roadmap for branded titles, rebuilding, inspection, and approval.",
    keywords: ["salvage", "rebuilt", "inspection", "total loss"],
    source: "https://mva.maryland.gov/title-registration/title-vehicle/salvaged-vehicles",
  },
  {
    title: "Private-party purchase",
    category: "Title",
    status: "verify",
    summary: "Title assignment, bill of sale, tax, inspection, and plate questions to verify.",
    keywords: ["private sale", "buyer", "seller", "tax"],
    source: "https://mva.maryland.gov/title-registration/title-vehicle/private-party-purchase",
  },
  {
    title: "Gift or family transfer",
    category: "Title",
    status: "verify",
    summary: "Relationship, exemption, ownership, lien, and inspection questions to confirm.",
    keywords: ["gift", "family", "relative", "exemption"],
    source: "https://mva.maryland.gov/title-registration/buying-selling-or-gifting-vehicle",
  },
];

function Mark() {
  return <span className="brand-mark" aria-hidden="true"><i /><i /><i /><i /></span>;
}

export default function Home() {
  const [query, setQuery] = useState("");
  const [serviceQuery, setServiceQuery] = useState("");
  const [notice, setNotice] = useState("");
  const [openFaq, setOpenFaq] = useState(0);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [bookingOpen, setBookingOpen] = useState(false);
  const [selectedService, setSelectedService] = useState(services[0].title);
  const searchRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (!notice) return;
    const timer = window.setTimeout(() => setNotice(""), 3200);
    return () => window.clearTimeout(timer);
  }, [notice]);

  useEffect(() => {
    if (!bookingOpen) return;
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const closeOnEscape = (event: KeyboardEvent) => {
      if (event.key === "Escape") setBookingOpen(false);
    };
    window.addEventListener("keydown", closeOnEscape);
    return () => {
      document.body.style.overflow = previousOverflow;
      window.removeEventListener("keydown", closeOnEscape);
    };
  }, [bookingOpen]);

  const filteredGuides = useMemo(() => {
    const needle = query.trim().toLowerCase();
    if (!needle) return guides;
    return guides.filter((guide) =>
      [guide.title, guide.category, guide.summary, ...guide.keywords]
        .join(" ")
        .toLowerCase()
        .includes(needle),
    );
  }, [query]);

  const filteredServices = useMemo(() => {
    const needle = serviceQuery.trim().toLowerCase();
    if (!needle) return services;
    return services.filter((service) =>
      [service.title, service.description, ...service.includes].join(" ").toLowerCase().includes(needle),
    );
  }, [serviceQuery]);

  const placeholderAction = (label: string) => {
    setNotice(`${label}: demonstration complete. No live action was submitted.`);
  };

  const openBooking = (service = services[0].title) => {
    setSelectedService(service);
    setMobileOpen(false);
    setBookingOpen(true);
  };

  const faqs = [
    {
      q: "What should I bring to my appointment?",
      a: "It depends on the transaction. After booking, the customer should receive a tailored checklist covering ownership, identification, insurance, lien, inspection, and payment documents.",
    },
    {
      q: "Can everything be completed remotely?",
      a: "Document review and preparation can often begin remotely. Some transactions may still require original documents, inspections, signatures, or an in-person MVA or service-office step.",
    },
    {
      q: "Are fees shown online final?",
      a: "No. Government fees, taxes, service fees, and unusual transaction costs should be confirmed after the paperwork is reviewed and before payment is collected.",
    },
    {
      q: "Is Adewetan Tag & Title part of the MVA?",
      a: "No. This website is for an independent service business and should not imply government affiliation. Official rules and transaction eligibility remain subject to current MDOT MVA guidance.",
    },
    {
      q: "How long will my transaction take?",
      a: "Timing depends on the transaction, document completeness, inspections, liens, and MDOT MVA processing. An estimated service timeline should be provided after the initial document review; no completion date is guaranteed until the requirements are confirmed.",
    },
    {
      q: "Do you accept walk-ins?",
      a: "Service is currently presented as appointment-based. Walk-in availability, public hours, and the service location will be published after the business details are verified.",
    },
    {
      q: "What identification and documents are commonly reviewed?",
      a: "A valid ID, proof of ownership, insurance information, lien documents, inspection records, and transaction-specific Maryland forms may be needed. Your exact checklist will depend on the vehicle and service requested.",
    },
  ];

  return (
    <main>
      <header className="site-header">
        <div className="concept-banner"><b>Pre-launch concept</b><span>This website is a demonstration. Services, appointments, and payments are not currently active.</span></div>
        <div className="page-shell nav-inner">
          <a className="brand" href="#top" aria-label="Adewetan Tag and Title home">
            <Mark />
            <span>Adewetan Tag &amp; Title</span>
          </a>
          <nav aria-label="Primary navigation">
            <a href="#services">Services</a>
            <a href="#process">How it works</a>
            <a href="#resources">Resources</a>
            <a href="#contact">Contact</a>
          </nav>
          <button className="nav-cta" type="button" onClick={() => openBooking()}>
            Preview booking <span>↗</span>
          </button>
          <button className="menu-toggle" type="button" onClick={() => setMobileOpen(!mobileOpen)} aria-expanded={mobileOpen} aria-label="Toggle navigation">
            <span /><span />
          </button>
        </div>
        {mobileOpen && (
          <nav className="mobile-nav page-shell" aria-label="Mobile navigation">
            <a href="#services" onClick={() => setMobileOpen(false)}>Services</a>
            <a href="#process" onClick={() => setMobileOpen(false)}>How it works</a>
            <a href="#resources" onClick={() => setMobileOpen(false)}>Resources</a>
            <a href="#contact" onClick={() => setMobileOpen(false)}>Contact</a>
          </nav>
        )}
      </header>

      <section className="business-hero" id="top">
        <div className="hero-stripe stripe-one" />
        <div className="hero-stripe stripe-two" />
        <div className="page-shell hero-layout">
          <div className="hero-copy">
            <div className="launch-label"><i /> Serving Maryland vehicle owners</div>
            <p className="eyebrow">Maryland vehicle paperwork support</p>
            <h1>Your vehicle.<br /><em>Your paperwork.</em><br />Handled clearly.</h1>
            <p className="hero-text">
              Straightforward help with Maryland titles, registration, tags, duplicate documents, and complex vehicle situations.
            </p>
            <div className="hero-actions">
              <button className="primary-action" type="button" onClick={() => openBooking()}>
                Preview booking <span>↗</span>
              </button>
              <a className="secondary-action" href="#services">Explore services</a>
            </div>
            <div className="hero-trust">
              <span><i>✓</i> Document pre-checks</span>
              <span><i>✓</i> Clear next steps</span>
              <span><i>✓</i> Remote intake</span>
            </div>
          </div>

          <aside className="intake-card" aria-label="Quick appointment start">
            <div className="intake-top"><span>Start here</span><b>01 / 03</b></div>
            <h2>What do you need help with?</h2>
            <div className="intake-options">
              {services.slice(0, 5).map((service) => (
                <button type="button" key={service.title} onClick={() => openBooking(service.title)}>
                  <span>{service.title}</span><b>→</b>
                </button>
              ))}
            </div>
            <p>No payment is collected until the live Square account is connected.</p>
          </aside>
        </div>
      </section>

      <section className="proof-strip" aria-label="Business highlights">
        <div className="page-shell">
          <span>Built for Maryland drivers</span>
          <i />
          <span>Six core service paths</span>
          <i />
          <span>Appointment-based service</span>
          <i />
          <span>Independent guidance</span>
        </div>
      </section>

      <section className="trust-section page-shell" aria-labelledby="trust-title">
        <div className="trust-heading">
          <p className="eyebrow red">Why Adewetan</p>
          <h2 id="trust-title">Clear answers before<br />you spend time or money.</h2>
        </div>
        <div className="trust-points">
          <article><span>01</span><h3>Maryland-focused</h3><p>Built around Maryland vehicle transactions and current MDOT MVA source material.</p></article>
          <article><span>02</span><h3>Checklist-first</h3><p>Know which documents matter before the appointment begins.</p></article>
          <article><span>03</span><h3>Honest boundaries</h3><p>See what the service can prepare—and what still requires official approval.</p></article>
        </div>
      </section>

      <section className="services-section page-shell" id="services">
        <div className="section-heading">
          <div>
            <p className="eyebrow red">What we help with</p>
            <h2>Service without<br />the paperwork maze.</h2>
          </div>
          <p>Choose a service to begin. Each appointment starts with a transaction review so customers know what to bring and what still needs official confirmation.</p>
        </div>

        <label className="service-search" htmlFor="service-search"><span>Search service guides</span><input id="service-search" type="search" value={serviceQuery} onChange={(event) => setServiceQuery(event.target.value)} placeholder="Try title, renewal, tags, salvage…" /></label>

        <div className="service-grid">
          {filteredServices.map((service) => (
            <article className={`service-card ${service.accent}`} key={service.number}>
              <div className="service-number">{service.number}</div>
              <h3>{service.title}</h3>
              <p>{service.description}</p>
              <ul>{service.includes.map((item) => <li key={item}>{item}</li>)}</ul>
              <button type="button" onClick={() => openBooking(service.title)}>
                Preview this service <span>→</span>
              </button>
              <a className="service-guide-link" href={`/services/${service.slug}`}>Open detailed guide <span>↗</span></a>
            </article>
          ))}
        </div>
        {filteredServices.length === 0 && <div className="service-empty"><b>No matching service.</b><button type="button" onClick={() => setServiceQuery("")}>Show all guides</button></div>}
      </section>

      <section className="standards-section" aria-labelledby="standards-title">
        <div className="page-shell standards-layout">
          <div className="standards-copy">
            <p className="eyebrow">What professional service means</p>
            <h2 id="standards-title">No mystery fees.<br />No vague next steps.</h2>
            <p>Every customer should know what is being reviewed, which costs come from the government, which costs belong to the service, and what can delay the transaction.</p>
          </div>
          <div className="standards-list">
            <article><b>Before payment</b><h3>Written scope</h3><p>Clarify the requested service and required documents before collecting a service fee.</p></article>
            <article><b>Before submission</b><h3>Document check</h3><p>Flag missing signatures, liens, inspections, ownership gaps, or special-case requirements.</p></article>
            <article><b>Before completion</b><h3>Clear handoff</h3><p>Explain what has been submitted, what the customer keeps, and what happens next.</p></article>
          </div>
        </div>
      </section>

      <section className="process-section" id="process">
        <div className="page-shell process-layout">
          <div className="process-copy">
            <p className="eyebrow">A clearer process</p>
            <h2>From question<br />to completed.</h2>
            <p>Customers should never arrive unsure of what comes next. The site turns every inquiry into a simple three-part path.</p>
            <button type="button" onClick={() => openBooking()}>Preview appointment flow ↗</button>
          </div>
          <ol className="process-steps">
            <li>
              <span>01</span>
              <div><h3>Choose the transaction</h3><p>Select the closest service and share the basic vehicle situation.</p></div>
            </li>
            <li>
              <span>02</span>
              <div><h3>Get the right checklist</h3><p>Review ownership, ID, insurance, lien, inspection, and form requirements.</p></div>
            </li>
            <li>
              <span>03</span>
              <div><h3>Book, pay, and complete</h3><p>Choose an approved online or in-person payment option, then follow the final submission path.</p></div>
            </li>
          </ol>
        </div>
      </section>

      <section className="square-section page-shell" aria-labelledby="square-title">
        <div className="square-card">
          <div className="square-icon" aria-hidden="true"><span /></div>
          <div className="square-copy">
            <p className="eyebrow">Secure customer actions</p>
            <h2 id="square-title">Preview booking and payment.</h2>
            <p>This concept is designed to connect with Square when the business is ready to operate. No appointments or payments are currently accepted.</p>
          </div>
          <div className="square-actions">
            <button type="button" onClick={() => openBooking()}>
              <small>Demo only</small><span>Preview booking</span><b>↗</b>
            </button>
            <button type="button" onClick={() => placeholderAction("Square payment")}>
              <small>Demo only</small><span>Payment preview</span><b>↗</b>
            </button>
          </div>
          <div className="payment-methods" aria-label="Planned payment methods">
            <div className="payment-heading">
              <span>Payment options</span>
              <small>Available after service confirmation</small>
            </div>
            <ul>
              <li><i aria-hidden="true">CARD</i><span><b>Credit &amp; debit cards</b><small>Secure online checkout</small></span></li>
              <li><i aria-hidden="true">AP</i><span><b>Apple Pay</b><small>Eligible Apple devices</small></span></li>
              <li><i aria-hidden="true">GP</i><span><b>Google Pay</b><small>Eligible Android devices</small></span></li>
              <li><i aria-hidden="true">PP</i><span><b>PayPal</b><small>Payment link coming soon</small></span></li>
              <li><i aria-hidden="true">$</i><span><b>Cash App</b><small>Payment profile coming soon</small></span></li>
              <li><i aria-hidden="true">Z</i><span><b>Zelle</b><small>Payment details coming soon</small></span></li>
              <li><i aria-hidden="true">IN</i><span><b>Pay in person</b><small>Confirm at appointment</small></span></li>
            </ul>
            <p><b>Concept notice:</b> Payment methods illustrate a future customer experience. No live Square account or payment destination is connected.</p>
          </div>
        </div>
      </section>

      <section className="resources-section page-shell" id="resources">
        <div className="section-heading resources-heading">
          <div>
            <p className="eyebrow red">Free reference library</p>
            <h2>Know before<br />you book.</h2>
          </div>
          <div className="resource-search">
            <label htmlFor="guide-search">Search transaction guides</label>
            <div><span className="search-icon" /><input ref={searchRef} id="guide-search" type="search" value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Lost title, renewal, salvage…" /></div>
          </div>
        </div>

        <div className="guide-list" aria-live="polite">
          {filteredGuides.map((guide, index) => (
            <article key={guide.title}>
              <span className="guide-index">{String(index + 1).padStart(2, "0")}</span>
              <div className="guide-body">
                <div className="guide-meta"><span className={guide.status}>{guide.status === "checked" ? "Source-checked" : "Verify details"}</span><i>{guide.category}</i></div>
                <h3>{guide.title}</h3>
                <p>{guide.summary}</p>
              </div>
              <a href={guide.source} target="_blank" rel="noreferrer" aria-label={`Open official source for ${guide.title}`}>Official source ↗</a>
            </article>
          ))}
          {filteredGuides.length === 0 && (
            <div className="resource-empty"><strong>No guide found.</strong><button type="button" onClick={() => { setQuery(""); searchRef.current?.focus(); }}>Show all guides</button></div>
          )}
        </div>
      </section>

      <section className="faq-section">
        <div className="page-shell faq-layout">
          <div><p className="eyebrow red">Common questions</p><h2>Before you<br />get started.</h2></div>
          <div className="faq-list">
            {faqs.map((faq, index) => (
              <article className={openFaq === index ? "open" : ""} key={faq.q}>
                <button type="button" onClick={() => setOpenFaq(openFaq === index ? -1 : index)} aria-expanded={openFaq === index}>
                  <span>{faq.q}</span><b>{openFaq === index ? "−" : "+"}</b>
                </button>
                {openFaq === index && <p>{faq.a}</p>}
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="contact-section" id="contact">
        <div className="page-shell contact-layout">
          <div className="contact-info">
            <p className="eyebrow">Contact Adewetan Tag &amp; Title</p>
            <h2>Ready when<br />you are.</h2>
            <p className="contact-intro">Ask a question, request a document review, or start an appointment.</p>
            <div className="service-area"><span>Service area</span><strong>Maryland</strong><small>Remote document review available</small></div>
            <dl>
              <div><dt>Phone</dt><dd><a href="tel:+13012184146">301-218-4146</a></dd></div>
              <div><dt>Email</dt><dd><a href="mailto:adewetantag&title@gmail.com">adewetantag&amp;title@gmail.com</a></dd></div>
              <div><dt>Address</dt><dd><a href="https://www.google.com/maps/search/?api=1&query=30630+Umes+Blvd+Princess+Anne+MD+21853" target="_blank" rel="noreferrer">30630 Umes Blvd<br />Princess Anne, MD 21853 ↗</a></dd></div>
            </dl>
            <p className="placeholder-note"><b>Concept contact details:</b> The information above is included for project planning. This website does not represent an open office or invite customer visits.</p>
          </div>

          <article className="contact-form demo-contact" aria-labelledby="demo-contact-title">
            <div className="form-heading"><span id="demo-contact-title">Contact flow preview</span><small>Demo only</small></div>
            <div className="demo-contact-card"><b>No personal information is collected</b><p>A future launch can add a secure inquiry form after the business inbox, privacy policy, and data-handling process are confirmed.</p></div>
            <div className="demo-contact-steps"><span>01 · Choose a service</span><span>02 · Receive a checklist</span><span>03 · Confirm an appointment</span></div>
            <button type="button" onClick={() => openBooking()}>Preview customer journey <span>→</span></button>
            <p>Please do not submit titles, identification, VINs, insurance records, or other sensitive documents through this concept site.</p>
          </article>
        </div>
      </section>

      <section className="policy-section" id="policies" aria-labelledby="policy-title">
        <div className="page-shell">
          <div className="policy-heading">
            <div><p className="eyebrow red">Customer protections</p><h2 id="policy-title">Clear policies before you commit.</h2></div>
            <p>Final business terms will be published before launch. These principles show customers what to expect now.</p>
          </div>
          <div className="policy-grid">
            <article><span>01</span><h3>Fees &amp; estimates</h3><p>Government charges, taxes, third-party costs, and Adewetan service fees will be identified separately before payment.</p><b>Final amounts require review</b></article>
            <article><span>02</span><h3>Cancellations</h3><p>The appointment cancellation window and any rescheduling rules will be shown before a customer books.</p><b>Terms pending verification</b></article>
            <article><span>03</span><h3>Refunds</h3><p>Refund eligibility will depend on work completed, costs already paid, and the final written service agreement.</p><b>Policy coming before launch</b></article>
            <article><span>04</span><h3>Privacy</h3><p>Customer and vehicle information should be collected only through approved channels and used to support the requested transaction.</p><b>Do not send sensitive documents yet</b></article>
          </div>
        </div>
      </section>

      <section className="launch-section" aria-labelledby="launch-title">
        <div className="page-shell launch-layout">
          <div className="launch-copy"><p className="eyebrow">Future launch plan</p><h2 id="launch-title">From concept to customer-ready.</h2><p>These items should be completed and verified before appointments or payments go live.</p></div>
          <ol className="launch-checklist">
            <li><b>01</b><span><strong>Business foundation</strong><small>Confirm ownership, legal structure, business name, tax setup, and banking.</small></span><i>Pending</i></li>
            <li><b>02</b><span><strong>Maryland authorization</strong><small>Verify every required license, registration, bond, insurance, and MDOT MVA relationship.</small></span><i>Pending</i></li>
            <li><b>03</b><span><strong>Operating details</strong><small>Approve services, prices, government-fee disclosures, hours, service area, and customer policies.</small></span><i>Pending</i></li>
            <li><b>04</b><span><strong>Secure customer systems</strong><small>Connect Square, business email delivery, document handling, privacy controls, and recordkeeping.</small></span><i>Pending</i></li>
            <li><b>05</b><span><strong>Final review &amp; launch</strong><small>Test mobile and desktop flows, verify all official guidance, then replace every demo label.</small></span><i>Pending</i></li>
          </ol>
        </div>
      </section>

      <footer>
        <div className="page-shell footer-grid">
          <div className="brand footer-brand"><Mark /><span>Adewetan Tag &amp; Title</span></div>
          <p>Pre-launch business concept for independent Maryland vehicle paperwork support. Not affiliated with MDOT MVA.</p>
          <div><a href="#services">Services</a><a href="#resources">Resources</a><a href="#policies">Policies</a><a href="#contact">Contact</a></div>
          <span>© 2026 Adewetan Tag &amp; Title concept · No services, appointments, or payments are currently offered through this website.</span>
        </div>
      </footer>

      {bookingOpen && (
        <div className="booking-layer" role="presentation" onMouseDown={(event) => {
          if (event.currentTarget === event.target) setBookingOpen(false);
        }}>
          <section className="booking-panel" role="dialog" aria-modal="true" aria-labelledby="booking-title">
            <div className="booking-header">
              <div><p>Adewetan Tag &amp; Title</p><span>Booking-flow preview</span></div>
              <button type="button" onClick={() => setBookingOpen(false)} aria-label="Close booking panel">×</button>
            </div>
            <div className="booking-progress" aria-label="Booking progress"><i className="active" /><i /><i /><span>Step 1 of 3</span></div>
            <div className="booking-body">
              <p className="eyebrow red">Choose a service</p>
              <h2 id="booking-title">What can we help you complete?</h2>
              <div className="booking-services">
                {services.map((service) => (
                  <button className={selectedService === service.title ? "selected" : ""} type="button" key={service.title} onClick={() => setSelectedService(service.title)}>
                    <span><small>{service.number}</small><b>{service.title}</b></span><i>{selectedService === service.title ? "✓" : ""}</i>
                  </button>
                ))}
              </div>
              <div className="booking-summary"><span>Selected service</span><strong>{selectedService}</strong><small>Final eligibility and fees depend on document review.</small></div>
            </div>
            <div className="booking-footer">
              <p><b>Demo only:</b> This preview does not submit an appointment or send information to Square.</p>
              <button type="button" onClick={() => placeholderAction("Square booking preview")}>Finish preview <span>↗</span></button>
            </div>
          </section>
        </div>
      )}

      <div className={`toast ${notice ? "show" : ""}`} role="status" aria-live="polite"><i>!</i><span>{notice}</span></div>
      <nav className="mobile-action-bar" aria-label="Quick customer actions">
        <a href="tel:+13012184146">Call</a>
        <button type="button" onClick={() => openBooking()}>Preview</button>
        <button type="button" onClick={() => placeholderAction("Payment preview")}>Pay demo</button>
      </nav>
    </main>
  );
}
