import type { Metadata } from "next";
import { getServiceGuide, serviceGuides } from "../../service-guides";

export function generateStaticParams() {
  return serviceGuides.map((guide) => ({ slug: guide.slug }));
}

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params;
  const guide = getServiceGuide(slug);
  return { title: guide ? `${guide.title} Guide | Adewetan Tag & Title` : "Service Guide" };
}

export default async function ServiceGuidePage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const guide = getServiceGuide(slug);
  if (!guide) return <main className="guide-page"><section className="guide-hero"><div className="guide-shell"><a href="/">← Back home</a><h1>Guide not found.</h1></div></section></main>;

  return (
    <main className="guide-page">
      <div className="concept-banner"><b>Pre-launch reference</b><span>This guide is informational and does not offer an active service.</span></div>
      <header className="guide-nav"><div className="guide-shell"><a href="/">Adewetan Tag &amp; Title</a><a href="/#services">All service guides</a></div></header>
      <section className="guide-hero"><div className="guide-shell"><span>{guide.number} · Maryland service guide</span><h1>{guide.title}</h1><p>{guide.intro}</p><div><b>Reference status</b><strong>Official details still require transaction-specific verification</strong></div></div></section>
      <div className="guide-shell guide-content">
        <section className="guide-panel"><p className="eyebrow red">Who this may help</p><h2>Start with the situation.</h2><ul>{guide.audience.map((item) => <li key={item}>{item}</li>)}</ul></section>
        <section className="guide-panel guide-docs"><p className="eyebrow red">Common documents</p><h2>Prepare for review.</h2><p className="guide-caution">Do not send sensitive documents through this concept site. The exact checklist can change by transaction.</p><ul>{guide.documents.map((item) => <li key={item}><i>✓</i><span>{item}</span></li>)}</ul></section>
        <section className="guide-panel guide-wide"><p className="eyebrow red">Typical process</p><h2>A clearer path forward.</h2><ol>{guide.steps.map((item, index) => <li key={item}><b>{String(index + 1).padStart(2, "0")}</b><span>{item}</span></li>)}</ol></section>
        <section className="guide-panel"><p className="eyebrow red">What can delay it</p><h2>Watch these blockers.</h2><ul>{guide.delays.map((item) => <li key={item}>{item}</li>)}</ul></section>
        <section className="guide-panel guide-fees"><p className="eyebrow red">Fees &amp; boundaries</p><h2>Separate every cost.</h2><p>{guide.feeNote}</p><div><b>Verification note</b><span>{guide.verification}</span></div></section>
        <section className="guide-panel guide-wide"><p className="eyebrow red">Questions</p><h2>Quick answers.</h2><div className="guide-faqs">{guide.faqs.map((faq) => <article key={faq.q}><h3>{faq.q}</h3><p>{faq.a}</p></article>)}</div></section>
        <section className="guide-sources"><div><p className="eyebrow">Official Maryland sources</p><h2>Verify before acting.</h2></div><div>{guide.sources.map((source) => <a key={source.url} href={source.url} target="_blank" rel="noreferrer">{source.label}<span>↗</span></a>)}</div></section>
      </div>
      <footer className="guide-footer"><div className="guide-shell"><p>Adewetan Tag &amp; Title is a pre-launch concept and is not affiliated with MDOT MVA.</p><a href="/">Return to the full website →</a></div></footer>
    </main>
  );
}
