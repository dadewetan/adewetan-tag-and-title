export type ServiceGuide = {
  slug: string; number: string; title: string; intro: string;
  audience: string[]; documents: string[]; steps: string[]; delays: string[];
  feeNote: string; verification: string;
  sources: { label: string; url: string }[];
  faqs: { q: string; a: string }[];
};

export const serviceGuides: ServiceGuide[] = [
  {
    slug: "title-transfers", number: "01", title: "Title transfers",
    intro: "A planning guide for private purchases, gifts, inherited vehicles, and other Maryland ownership changes.",
    audience: ["Private-party buyers and sellers", "Family gift transfers", "Owners handling an inherited or specially acquired vehicle"],
    documents: ["Properly assigned original title", "Maryland title application or completed pre-application", "Proof of purchase price or bill of sale when applicable", "Odometer disclosure when applicable", "Maryland safety inspection certification", "Valid identification", "Lien release when a lien appears on the title"],
    steps: ["Identify exactly how the vehicle was acquired.", "Review the ownership document for signatures, dates, odometer entry, and alterations.", "Match the transaction to the correct Maryland application and supporting records.", "Confirm inspection, insurance, lien, tax, registration, and plate requirements.", "Verify the final submission method and government fees with MDOT MVA."],
    delays: ["Cross-outs or incomplete title assignment", "Open or recently released liens", "Missing inspection certification", "Purchase-price or relationship documentation questions", "Out-of-state, inherited, auction, or branded-title history"],
    feeNote: "Maryland taxes and MVA fees depend on the transaction. Any future Adewetan service fee must be quoted separately in writing.",
    verification: "Based on current MDOT MVA overview material. Transaction-specific eligibility and documents must still be confirmed.",
    sources: [{ label: "Title a vehicle", url: "https://mva.maryland.gov/title-registration/title-vehicle" }, { label: "Private-party purchase", url: "https://mva.maryland.gov/title-registration/title-vehicle/private-party-purchase" }, { label: "Buying, selling or gifting", url: "https://mva.maryland.gov/title-registration/buying-selling-or-gifting-vehicle" }],
    faqs: [{ q: "Is a bill of sale always required?", a: "Not in every transaction, but proof of purchase price may be required and a bill of sale is strongly recommended." }, { q: "Can an altered title be accepted?", a: "Errors, cross-outs, or altered entries can cause rejection. Confirm the required correction before submitting." }],
  },
  {
    slug: "registration-renewals", number: "02", title: "Registration & renewals",
    intro: "A starting point for first-time Maryland registration, ordinary renewals, and common renewal blockers.",
    audience: ["Current Maryland registrants", "New Maryland residents", "Owners resolving insurance, emissions, toll, parking, or other flags"],
    documents: ["Renewal notice or registration details", "Vehicle title information", "Maryland insurance information", "Valid identification when required", "Inspection or emissions documentation when applicable", "Flag-resolution confirmation when applicable"],
    steps: ["Determine whether this is an initial registration, renewal, replacement, or correction.", "Check insurance, emissions, safety inspection, and vehicle-flag status.", "Confirm the available online, kiosk, mail, branch, or licensed-service channel.", "Review the registration term, plate status, and government fees.", "Keep the confirmation and updated registration record."],
    delays: ["Unresolved vehicle flags", "Insurance compliance issues", "Outstanding emissions requirement", "Incorrect address or owner information", "Title or plate mismatch"],
    feeNote: "Registration charges vary by vehicle and term. Use the official MVA fee schedule and separate any future service charge.",
    verification: "Renewal eligibility and available channels can vary. Confirm the current status through myMVA or MDOT MVA.",
    sources: [{ label: "Title & registration", url: "https://mva.maryland.gov/title-registration" }, { label: "New Maryland residents", url: "https://mva.maryland.gov/your-mva-guide/new-maryland-residents/title-register-your-vehicle" }, { label: "MVA fees", url: "https://mva.maryland.gov/title-registration/fees-payment-options" }],
    faqs: [{ q: "Why might a renewal be blocked?", a: "Common causes include insurance, emissions, toll, parking, or other vehicle flags." }, { q: "What does a new Maryland resident do?", a: "New residents generally follow Maryland title-and-registration steps rather than a Maryland renewal path." }],
  },
  {
    slug: "tags-license-plates", number: "03", title: "Tags & license plates",
    intro: "Guidance for Maryland plate issuance, transfers, replacements, and transaction-specific tag questions.",
    audience: ["Owners registering a newly acquired vehicle", "Drivers transferring eligible plates", "Customers replacing lost, stolen, or damaged plates"],
    documents: ["Current registration or title-transaction records", "Plate number and vehicle information", "Valid identification", "Insurance information", "Loss or theft documentation when required", "Specialty-plate eligibility documentation when applicable"],
    steps: ["Identify whether plates are being issued, transferred, replaced, returned, or changed.", "Confirm the owner, vehicle class, registration, and insurance support the request.", "Review standard, specialty, disability, personalized, and temporary-tag rules as applicable.", "Select an approved MVA submission channel.", "Confirm stickers, registration card, and any plate-return obligation."],
    delays: ["Plate and owner information do not match", "Registration or insurance is inactive", "Specialty eligibility is incomplete", "Personalized configuration is unavailable", "Transaction requires title work first"],
    feeNote: "Plate and registration fees vary by type and transaction. Confirm official charges before quoting any future service fee.",
    verification: "Plate availability, transfer eligibility, and replacement requirements must be checked for the exact vehicle and plate type.",
    sources: [{ label: "Maryland license plates", url: "https://mva.maryland.gov/title-registration/license-plates" }, { label: "Fees & payment options", url: "https://mva.maryland.gov/title-registration/fees-payment-options" }],
    faqs: [{ q: "Can Maryland plates be transferred?", a: "Eligible plate transfers can be requested when registering another vehicle, but ownership and vehicle rules apply." }, { q: "Do plates come before the title?", a: "The plate request is usually part of registration and may depend on completing the title transaction first." }],
  },
  {
    slug: "duplicate-titles", number: "04", title: "Duplicate titles",
    intro: "A replacement-title guide for Maryland titles that are lost, stolen, damaged, destroyed, or never received.",
    audience: ["Registered owners missing the original title", "Owners with an unreadable or damaged title", "Owners resolving a prior lien before replacement"],
    documents: ["Application for Duplicate Certificate of Title (VR-018) when required", "Valid identification", "Vehicle and title information", "Lien release if a prior lien remains recorded", "Required MVA fee"],
    steps: ["Confirm that a duplicate—not a title correction—is the right request.", "Check the owner record, mailing address, and lien status.", "Choose an eligible online, in-person, or mail request method.", "Complete the application and supporting records.", "Track delivery or pickup and protect the replacement title."],
    delays: ["Active or recently released lien", "Owner or address mismatch", "Request is actually a correction", "Vehicle is not eligible for the selected channel", "Missing signature, identification, or payment"],
    feeNote: "The current VR-018 form lists a $40 duplicate-title fee, but confirm the latest official amount before payment.",
    verification: "Source-checked against MDOT MVA guidance and the current VR-018 form. Eligibility still depends on the vehicle record.",
    sources: [{ label: "Request a duplicate title", url: "https://mva.maryland.gov/title-registration/request-duplicate-title" }, { label: "VR-018 application", url: "https://mva.maryland.gov/media/159" }],
    faqs: [{ q: "Can a duplicate fix incorrect information?", a: "No. MDOT MVA directs customers with incorrect title information to the title-correction process." }, { q: "Can I request it online?", a: "Eligible individual owners may use myMVA; special circumstances may require another channel." }],
  },
  {
    slug: "salvage-rebuilt-vehicles", number: "05", title: "Salvage & rebuilt vehicles",
    intro: "A high-level roadmap for branded records, rebuilding, inspection, titling, and return-to-road questions.",
    audience: ["Owners of insurance total-loss vehicles", "Rebuilders and purchasers of salvage vehicles", "Customers handling an out-of-state branded title"],
    documents: ["Existing title, salvage certificate, or ownership record", "Proof of acquisition", "Repair and parts records", "Inspection materials when required", "Lien or insurer documentation when applicable", "Identity and vehicle information", "Required applications and fees"],
    steps: ["Identify the exact current title brand and ownership chain.", "Confirm who is responsible for the salvage-title step.", "Retain repair, parts, and ownership documentation.", "Complete every required salvage and safety inspection in the correct order.", "Apply for the appropriate branded title and registration only after approval."],
    delays: ["Missing ownership chain or insurer documents", "Unverifiable parts or repair records", "Inspection scheduling or failure", "Out-of-state brand differences", "Vehicle is not eligible to return to road use"],
    feeNote: "Certificates, inspections, title work, taxes, towing, repairs, and future service charges are separate costs.",
    verification: "This is only a roadmap. Salvage and rebuilt transactions require direct MDOT MVA and inspection confirmation.",
    sources: [{ label: "Salvaged vehicles", url: "https://mva.maryland.gov/title-registration/title-vehicle/salvaged-vehicles" }, { label: "Maryland safety inspections", url: "https://mva.maryland.gov/title-registration/vehicle-emissions-safety-inspections/safety-inspections" }, { label: "Fees & payment options", url: "https://mva.maryland.gov/title-registration/fees-payment-options" }],
    faqs: [{ q: "Can a salvage vehicle be driven immediately?", a: "No. MDOT MVA says it cannot be registered or driven until rebuilt, inspected, and approved." }, { q: "Is one inspection enough?", a: "Requirements depend on the brand and case. Confirm the complete inspection sequence first." }],
  },
  {
    slug: "mobile-remote-service", number: "06", title: "Mobile or remote service",
    intro: "A proposed pre-launch workflow for reviewing paperwork and planning a transaction before an in-person step.",
    audience: ["Customers seeking an initial paperwork review", "People who want a checklist before traveling", "Customers with mobility, schedule, or distance constraints"],
    documents: ["Only non-sensitive summaries during the concept phase", "Transaction type and general vehicle situation", "A list of available ownership records", "Questions about liens, inspection, insurance, or residency", "Original documents only through a future approved process"],
    steps: ["Choose the closest service guide.", "Describe the situation without sending sensitive records.", "Receive a preliminary checklist and verification questions.", "Confirm which originals, signatures, inspections, or in-person steps remain.", "Use an approved secure channel only after the business launches."],
    delays: ["Original documents or notarization required", "Inspection must occur in person", "Identity or ownership cannot be verified remotely", "Secure upload and privacy process not active", "MVA appointment or licensed-provider step required"],
    feeNote: "No remote-service fee is active. Future pricing must separate review work from government and third-party charges.",
    verification: "This is a proposed service model, not an active MVA program. Licensing, privacy, records, and operations require review.",
    sources: [{ label: "MDOT MVA title & registration", url: "https://mva.maryland.gov/title-registration" }, { label: "MDOT MVA home", url: "https://mva.maryland.gov/" }],
    faqs: [{ q: "Can I send a photo of my title now?", a: "No. This concept site has no approved secure channel for sensitive documents." }, { q: "Can the whole transaction be remote?", a: "Not necessarily. Originals, inspection, signatures, identity verification, or an in-person step may be required." }],
  },
];

export const getServiceGuide = (slug: string) => serviceGuides.find((guide) => guide.slug === slug);
